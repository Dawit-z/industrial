@extends('layout')
@section('content')

<div class="container">
    <div class="row">
        <div class="col-sm-4">
            <h2>Contact Us</h2>
            <h5>Feel free to call at anytime :) </h5>
           
<p>+251 94 718 6055</p>

</div>

@stop