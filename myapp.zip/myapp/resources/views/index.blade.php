@extends('layout')
@section('content')

<div class="container">
    <div class="row">
        <div class="col-sm-4">
            <h2>Welcome</h2>
            <h5>Photo of Us</h5>
            <div class="fakeimg"><img src="{{asset('/images/DSC_5773.JPG')}}" height="200" width="400" style="float: left"></div>
<p>Welcome to the Republics first laravel project</p>

</div>

@stop