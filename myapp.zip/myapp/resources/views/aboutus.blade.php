@extends('layout')
@section('content')
/*
<div class="container">
    <div class="row">
        <div class="col-sm-4">
            <h2>About Us</h2>
            <h5>We are a group of informaion systems students working on an industrial project</h5>
           

</div>
*/
@stop