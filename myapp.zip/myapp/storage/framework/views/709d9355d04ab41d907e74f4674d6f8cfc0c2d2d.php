
<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-sm-4">
            <h2>Contact Us</h2>
            <h5>Feel free to call at anytime :) </h5>
           
<p>+251 94 718 6055</p>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myapp\resources\views/contactus.blade.php ENDPATH**/ ?>