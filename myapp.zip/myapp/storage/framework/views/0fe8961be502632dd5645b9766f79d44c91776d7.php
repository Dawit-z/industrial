
<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-sm-4">
            <h2>Welcome</h2>
            <h5>Photo of Us</h5>
            <div class="fakeimg"><img src="<?php echo e(asset('/images/DSC_5773.JPG')); ?>" height="200" width="400" style="float: left"></div>
<p>Welcome to the Republics first laravel project</p>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myapp\resources\views/index.blade.php ENDPATH**/ ?>